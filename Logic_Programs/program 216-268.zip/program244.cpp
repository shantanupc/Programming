#include<iostream>
using namespace std;

int main()
{
    char Arr[30];

    cout<<"Enter your name :"<<endl;
    cin>>Arr;

    cout<<"Hello "<<Arr<<endl;

    return 0;
}